﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusBookingLibrary
{
    public class BusDbContext : DbContext
    {
        public DbSet<Booking> Bookings  { get; set; }
        public DbSet<User> Users        { get; set; }
        public DbSet<Vehicle> Vehicles  { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {            
            string conStr = "Integrated Security=SSPI;Server=.;DataBase=BusBooking";

            optionsBuilder.UseSqlServer(conStr);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
