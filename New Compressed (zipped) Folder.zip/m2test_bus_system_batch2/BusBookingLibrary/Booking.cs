﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusBookingLibrary
{
    public enum Status
    {
        Confirmed=1
        ,WaitingList
        ,Canceled
    }

    public class Booking
    {
        [Key]
        public int BookingId { get; set; } 
        public Vehicle Vehicle { get; set; }
        public string Customer { get; set; }
        public Status Status { get; set; }
    }
}
