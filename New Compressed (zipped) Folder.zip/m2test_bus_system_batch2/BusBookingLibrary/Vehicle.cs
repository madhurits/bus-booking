﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BusBookingLibrary
{
    public class Vehicle
    {
        [Key]
        public string BusType { get; set; }
        public string Operator_Name { get; set; }
        [Required (ErrorMessage ="Enter a valid number")]
        public int Vehicle_Number { get; set; }
        public bool IsAcCoach { get; set; }
        public bool IsSleeper { get; set; }
        public DateTime DateOfJourney { get; set; }
        public int MaxSeatsAvailable { get; set; }
    
    
    }
}
