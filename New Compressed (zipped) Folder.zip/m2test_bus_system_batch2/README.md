The requirement is to create a simple vechile booking system with a waitist and automatic confirmation
The key entities are as below and have the following defenitions
**1. Vechile**

Bus Type, Operator Name, Vechile Number, IsAcCoach,IsSleeper, DateOfJourney,MaxSeatsAvailable
* Validation Required for Vechile number to ensure its a valid registration number
**2. User**
Name,Email,MobileNumber
**3. Booking**
BookingId,Vechile,Customer,Status ( Confirmed,WaitingList,Canceled)
Requirements.
* 1. User Provides BusType and the application must show all the buses of that type with the total seats available. 
* 2. User can click on any of the bus desired and provide the number of seats and book the vechile.
* 3. Book button must be visible only for logged in users how ever both logged in and anonymous users will be able to see the list of buses.
* 4. When booked if the number of available seats are more than the number of seats booked by the customer the status of the booking will be considered confirmed.
* 5. When booked if the number of avaible seats are less then the number of seats booked by the customer then the status wil be set as WaitingList
* 6. For logged in customers there should be a option to see the bookings made by that customer and cancel the booking if necessary.
* 7. If the customer chooses to cancel the booking then  while completing the cancellation process the number of seats booked for that booking should be used to change the status of waitinglist of confirmed.

for eg. 
customer 1 has 2 seats booked and confirmed
customer 2 has 1 seat booked and in waiting list
customer 3 has 1 seat booked and in waiting list
if customer 1 cancels the booking customer 2 and customer 3 should have their waiting list changed to confirmed.

**Note : You are required to fork the repository and impement the change
