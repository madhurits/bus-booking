﻿using BusBookingLibrary;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BusBusBookingSytem.Controllers
{
    [Route("/bookbusticket")]
    [Authorize(Roles = "LoggedUser")]
    public class BookingController : Controller
    {
        BusDbContext context;

        public BookingController(BusDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                context.Vehicles.Add(vehicle);
                context.SaveChanges();

                Response.Redirect("/");
            }
            return View(vehicle);

        }
    }
}
