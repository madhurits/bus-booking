﻿using BusBookingLibrary;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BusBusBookingSytem.Controllers
{
    [Route("/login")]
    public class LoginController : Controller
    {
        BusDbContext context;

        public LoginController(BusDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(string email,long mobilenumber)
        {
            BusBookingLibrary.User user = context.Users.FirstOrDefault(d => d.Email == email && d.MobileNumber == mobilenumber);

            if (user != null)
            {
                var claims = new[]
               {
                    new Claim(ClaimTypes.Name,user.Email.ToString()),
                    new Claim(ClaimTypes.Role,user.Role.ToString()),

                };

                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

                Response.Redirect("/bookbusticket");
            }
            else
                ViewBag.Error = "Login Failed";

            return View();
        }
    }
}
