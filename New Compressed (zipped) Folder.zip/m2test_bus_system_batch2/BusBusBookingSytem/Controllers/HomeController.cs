﻿using BusBookingLibrary;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace BusBusBookingSytem.Controllers
{
    [Route("/")]
    [Authorize]
    public class HomeController : Controller
    {
        BusDbContext context;

        public HomeController(BusDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Models = context.Vehicles;
            return View();
        }

        [HttpPost]
        public IActionResult Index(string bustype)
        {
            ViewBag.Vehicles = context.Vehicles.Where(d => d.BusType.Contains(bustype));
            return View();
        }

        //login details:
        //email:madhurits@gmail.com 
        //mobilenumber:8660730395

    }
}
